package com.util;

public final class StringFormatter {

	public static void main(String[] args) {
		System.out.println(String.format("//a[text()='%s']","Gift aid Report"));
	}
}




