package com.businessDefinations;

import java.sql.*;

public class check {
//    public static void main(String[] args) {
//
//        String driver = "com.mysql.jdbc.Driver";
//        String jdbcUrl = "jdbc:mysql://3.22.57.252:3306/mydatabase?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
//        String username = "automationDB";
//        String password = "Auto@2020";
//        String sql = "SELECT `Name`,`WFH enabled(Y/N)`,`WFH Laptop or Desktop` FROM `bar01cap02bar04`";
////SELECT `Name`,`WFH enabled(Y/N)`,`WFH Laptop or Desktop` FROM `bar01cap02bar04`
//        try {
//            Class.forName(driver);
//            Connection conn = DriverManager.getConnection(jdbcUrl, username, password);
//            System.out.println("Database Connected successfully ");
//            Statement stmt = conn.createStatement();
//
//            ResultSet results = stmt.executeQuery(sql);
//
//            ResultSetMetaData metadata = results.getMetaData();
//            int columnCount = metadata.getColumnCount();
//            for (int i = 1; i <= columnCount; i++) {
//                System.out.println(metadata.getColumnName(i) + ", ");
//            }
//            System.out.println();
//            while (results.next()) {
//                String row = "";
//                for (int i = 1; i <= columnCount; i++) {
//                    row += results.getString(i) + ", ";
//                }
//                System.out.println(row);
//
//
//            }
//
//            System.out.println("Query Executed successfully ");
//        } catch (ClassNotFoundException e) {
//// TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//
//            e.printStackTrace();
//        }
//
//    }

}
