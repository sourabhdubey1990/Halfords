package com.businessDefinations;

import static com.framework.Framework.framework;
import com.common.UIOperator;
import com.framework.Framework;
import com.report.Logger;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import org.apache.poi.ss.usermodel.FractionFormat;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import cucumber.api.java.en.Then;

public class Module1StepDefinition {

UIOperator oUI= new UIOperator();
       //For Reference Purpose Only
       public void login(String strUrl) {
           try {

               framework.webDriver.get(strUrl);
               //enter the credentials
              if(oUI.isElementPresent("TextFieldObjecName")){
                  oUI.EnterText("TextFieldObjecName","UserID");
                  oUI.EnterText("PwdObjecName","****");
                  oUI.click("LoginButton");
                  oUI.fluentWait("HomepageText");
                  if(oUI.isElementPresent("HomepageText")){
                      Logger.WriteLog("Successfully landed on homepage after login",true,true);
                  }
                  else{
                      Logger.WriteLog("Successfully landed on homepage after login",false,true);
                  }
              }

           } catch (Exception e) {
                e.getMessage();
               Logger.WriteLog("Could not land on homepage after login",false,true);


           }
       }


}
