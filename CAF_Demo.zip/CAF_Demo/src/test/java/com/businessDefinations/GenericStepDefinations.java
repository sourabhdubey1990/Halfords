package com.businessDefinations;

import java.util.ArrayList;

import org.json.JSONObject;
import org.junit.Assert;
import com.common.UIOperator;
import com.framework.Framework;
import com.framework.WebDriverWrapper;
import com.report.ExtentReportsHandler;
import com.report.Logger;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GenericStepDefinations {

    public JSONObject testData;
    public static Framework framework;
    String parentHandle = null;
    public static UIOperator oUI;
    public ArrayList<String> newTab;
    public static boolean securityFlag = false;
    public static boolean IDVFlag = false;
    public static String cartTestID = null;
    public static boolean specialzedlinkExist = true;

    @Before
    public void Initialize(Scenario scenario) throws Throwable {
        /*Result list to store steps for consolidated report.
         * Initializing in before to avoid duplication of steps in DB*/
        //if(System.getProperty("BuildName")!=null && !System.getProperty("BuildName").equalsIgnoreCase("null")) {
        //CART.startNewBuild("Corporate","IPORTAL","Continuous_SIT_Regression",System.getProperty("BuildName"),true);
        //cartTestID= CART.addNewTestCase(scenario.getName());
        //}
        Logger.resultList = new ArrayList<>();
        /* Initializing framework class instance */
        framework = Framework.createInstance(scenario.getName());

        /*Initializing pass fail status*/
        Framework.isTestPassOrFail = true;
        oUI = Framework.framework.UI;
        testData = Framework.framework.testData;
        Logger.Initialize("AUTOMATION RESULT", scenario.getName());
        if (Framework.framework.webDriver == null) {
            WebDriverWrapper.LoadWebDriver();
        }
    }

    @After
    public void LogOff(Scenario scenario) {
        try {
            // Code for Logout
            Logger.WriteScenarioFooter(Framework.createInstance(scenario.getName()).strCurrentScenarioName);
            if (Framework.framework.webDriver != null) {
                try {
                    if (scenario.isFailed()) {
                        Logger.WriteLog("TestCase has failed , please refer Screenshot", false, true);
                    }
                    Framework.framework.webDriver.quit();
                } catch (Exception e) {
                    Framework.framework.webDriver.quit();
                    System.out.println(e.getMessage());
                }
                Framework.framework.webDriver = null;
                Logger.WriteScenarioFooter(scenario.getName());
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        	System.out.println(e.getMessage());
        } finally {
            //ExtentReportsHandler.inserValuesIntoDB(Logger.resultList);
            Logger.resultList.removeAll(Logger.resultList);
        }
    }

    @Given("^I want to use this template for my feature file$")
    public void Iwanttousethistemplateformyfeaturefile() {
    	System.out.println("Yahi hai");
    }
    
    @Given("^User launches URL$")
    public void user_launches_URL() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        System.out.println(" Checked for site");
        if(user_launches_myte_url()) {
            Thread.sleep(4000);
            System.out.println("Title : " + Framework.framework.webDriver.getTitle());
            Assert.assertTrue("MYTE page loaded", Framework.framework.webDriver.getTitle().equalsIgnoreCase("Time - MyTimeAndExpenses - Version MyTE 12.2.84"));

            try {
                if (oUI.existsElement("MyteLoginPopUp")) {
                    Thread.sleep(3000);
                    System.out.println("MYTE Tutorial Pop up is displayed !!");
                    Logger.WriteLog("MYTE Tutorial Pop up is displayed !!", true, true);
                    //Framework.framework.webDriver.findElement(By.id())
                    oUI.click("TutorialCloseBtn");
                    Thread.sleep(2000);
                    Logger.WriteLog("URL Launched successfully", true, true);
                }
                else{
                    Logger.WriteLog("MYTE Tutorial Pop up is not displayed , Continuing with flow :) ", true, true);
                }
            } catch (Exception e) {
                e.getMessage();
                System.out.println(" MYTE Tutorial Pop up is NOT present !!");
                Logger.WriteLog("MYTE Tutorial Pop up is NOT present", true, true);
            }
        }

        //Check for user login scenario


    }

    public boolean user_closes_myte_site() {
        try {
            Framework.framework.webDriver.quit();
            Logger.WriteLog("Browser is closed", true, true);
            return true;
        } catch (Exception e) {
            e.getMessage();
            System.out.println(e.getMessage());
        }
      return  true;
    }

    public boolean user_launches_myte_url() {
        boolean flag=false;
        try {

            System.out.println("Launching MYTE URL !!");
            Framework.framework.webDriver.get("https://myte.accenture.com");
            Framework.framework.webDriver.manage().window().maximize();
            Logger.WriteLog("MYTE URL Launched", true, true);
            flag= true;

        } catch (Exception e) {
            flag=false;
            e.getMessage();
            Logger.WriteLog("Could not launch MyTe URL!", false, true);
        }
        return flag;
    }


    @Given("^User is on myte login page$")
    public void user_is_on_myte_login_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }


    @And("^Logged User is on Home page$")
    public void validate_user_home_page() {

        try {
            System.out.println("MYTE Home page" + oUI.existsElement("timesheetstatus"));
            Assert.assertTrue("MYTE HOme page is launched ! ", oUI.existsElement("timesheetstatus"));
            Logger.WriteLog("MYTE HOme page is launched", true, true);
        } catch (Exception e) {
            e.getMessage();
            Logger.WriteLog("Homepage screen not loaded !", false, true);
        }
    }


    @And("^Click on tab$")
    public void click_on_tab() {
        try {

            oUI.clickOnWebElement("//*[@id='ctl00_ctl00_MainContentPlaceHolder_Expense-IN']//span");
            System.out.println("User Clicked on Expenses tab !!");
            Logger.WriteLog("User Clicked on Expenses tab", true, true);
        } catch (Exception e) {
            e.getMessage();
            Logger.WriteLog("Could not click on expenses tab on MyTe Homepage", false, true);
        }
    }

    @When("^User enters username and password$")
    public void user_enters_username_and_password(DataTable arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
        // E,K,V must be a scalar (String, Integer, Date, enum etc)
    }

    @When("^Click Login Button$")
    public void click_Login_Button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @Then("^User logins sucessfully$")
    public void user_logins_sucessfully() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @Then("^User logout successfully$")
    public void user_logout_successfully() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        try {
            Framework.framework.webDriver.quit();
            System.out.println("User is logged out successfully !!");
        } catch (Exception e) {

            e.getMessage();
        }
    }



}
